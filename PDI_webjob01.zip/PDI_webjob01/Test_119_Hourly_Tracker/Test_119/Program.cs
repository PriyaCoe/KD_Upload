﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Reflection.PortableExecutable;

namespace Hourly_webjob
{
    class Program
    {



        static void Main(string[] args)
        {
               // print

            DateTime today = DateTime.Today.AddDays(-1);
            var dat = today.ToString("yyyy-MM-dd");
            var database = "Teal_PDI03";
            string stmnt = String.Concat("Web job started for the date : ", dat);

            Console.WriteLine(stmnt);



            SqlConnectionStringBuilder builder1 = new SqlConnectionStringBuilder();  //sql connection
            
            builder1.DataSource = "thsk06btrrptdb";
            builder1.UserID = "iotadmin";
            builder1.Password = "ciql#wOd9ufls";
            builder1.InitialCatalog = database;
            string connStr = builder1.ConnectionString;
            Console.WriteLine("Database :"+database);


            //using (SqlConnection con = new SqlConnection(connStr) )    // using sql connection
            //{
                SqlConnection conn = new SqlConnection(connStr);
                SqlCommand cmdd = new SqlCommand("select AssetID as Machine_code, AssetName as MachineName,f.FunctionID as Line_code" +
                    " from tbl_Assets a inner join tbl_function f on a.FunctionName=f.FunctionID ", conn);
                //cmd.Parameters.AddWithValue("@date", dat);
                SqlDataAdapter da1 = new SqlDataAdapter(cmdd);
                DataTable assetdt1 = new DataTable();
            da1.Fill(assetdt1);

            Console.WriteLine("Aset details"+ assetdt1);


            int[] array = {3,2,1};

            Stopwatch timer = new Stopwatch();

            // Using a for loop to iterate through the array elements
            for (int i = 0; i < array.Length; i++)
            {
                // get current timestamp
               DateTime stime = DateTime.Now;
                timer.Start();
                string machine = "M"+array[i];
                Console.WriteLine("SP Executing started for "+ machine);
                SqlCommand dps = new SqlCommand("[SP_MIS_Hourly_New]", conn);
                dps.CommandType = CommandType.StoredProcedure;
                dps.CommandTimeout = 0;
                dps.Parameters.Add("@Date", SqlDbType.Date).Value = dat; //"2023-08-16";
                dps.Parameters.Add("@CompanyCode", SqlDbType.VarChar).Value = "TVS";
                dps.Parameters.Add("@PlantCode", SqlDbType.VarChar).Value = "TVS_Plant03";
                dps.Parameters.Add("@LineCode", SqlDbType.VarChar).Value = "PDI_UNIT03";
                dps.Parameters.Add("@MachineCode", SqlDbType.VarChar).Value = machine;

                SqlDataAdapter dpsda = new SqlDataAdapter(dps);
                DataTable dpst = new DataTable();
                dpsda.Fill(dpst);
                Console.WriteLine("SP Executed ended for "+ machine);
               
                timer.Stop();



                    SqlConnection conn1 = new SqlConnection(connStr);
                   SqlCommand rd = new SqlCommand("[sp_webjob_diag]", conn1);
                    rd.CommandType = CommandType.StoredProcedure;
                    rd.CommandTimeout = 0;
                    rd.Parameters.Add("@webjob", SqlDbType.VarChar).Value = "Hourly_Job"; //"2023-08-16";
                    rd.Parameters.Add("@timestamp", SqlDbType.DateTime).Value = stime;
                    rd.Parameters.Add("@duration", SqlDbType.VarChar).Value = timer.ElapsedMilliseconds;
                    // dps.Parameters.Add("@LineCode", SqlDbType.VarChar).Value = "mnal01";
                    rd.Parameters.Add("@machine", SqlDbType.VarChar).Value = machine;


                SqlDataAdapter rda = new SqlDataAdapter(rd);
                DataTable rdat = new DataTable();
                rda.Fill(rdat);

                Console.WriteLine($"elpsed time:{timer.ElapsedMilliseconds} milliseconds");
                timer.Reset();



                // run sp
            }
            //for (int i = 0; i < array.Length; i++)
            //{
            //    string machine = "M"+array[i];


            //    Console.WriteLine("SP Executing started for "+ machine);
            //    SqlCommand dps = new SqlCommand("[sp_webjob_diag]", conn);
            //    dps.CommandType = CommandType.StoredProcedure;
            //    dps.CommandTimeout = 0;
            //    dps.Parameters.Add("@webjob", SqlDbType.VarChar).Value = "Hourly_Job"; //"2023-08-16";
            //    dps.Parameters.Add("@timestamp", SqlDbType.DateTime).Value = dat;
            //    dps.Parameters.Add("@duration", SqlDbType.VarChar).Value = "10";
            //    // dps.Parameters.Add("@LineCode", SqlDbType.VarChar).Value = "mnal01";
            //    dps.Parameters.Add("@machine", SqlDbType.VarChar).Value = machine;

            //    SqlDataAdapter dpsda = new SqlDataAdapter(dps);
            //    DataTable dpst = new DataTable();
            //    dpsda.Fill(dpst);
            //    Console.WriteLine("SP Executed ended for "+ machine);
            //}





            //for (int i = 1; i <= assetdt1.Rows.Count ; i++)
            //{

            //string machine = "M"+i;
            //    //Console.WriteLine("SP Executing started for "+ machine);
            //    SqlCommand dps = new SqlCommand("[SP_MIS_Hourly_New]", conn);
            //    dps.CommandType = CommandType.StoredProcedure;
            //    dps.CommandTimeout = 0;
            //    dps.Parameters.Add("@Date", SqlDbType.Date).Value = dat; //"2023-08-16";
            //    dps.Parameters.Add("@CompanyCode", SqlDbType.VarChar).Value = "TeaL_dtvs";
            //    dps.Parameters.Add("@PlantCode", SqlDbType.VarChar).Value = "TeaL_dtvs01";
            //    dps.Parameters.Add("@LineCode", SqlDbType.VarChar).Value = "mnal01";
            //    dps.Parameters.Add("@MachineCode", SqlDbType.VarChar).Value = machine;

            //     SqlDataAdapter dpsda = new SqlDataAdapter(dps);
            //     DataTable dpst = new DataTable();
            //     dpsda.Fill(dpst);
            //    Console.WriteLine("SP Executed ended for "+ machine);

            //}

        }

        }
    }
//}

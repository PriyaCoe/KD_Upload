﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace Hourly_webjob
{
    class Program
    {
        static void Main(string[] args)
        {
            // Array of connection strings
            string[] connectionStrings = {
                "Data Source=thsk06btrrptdb;Initial Catalog=Teal_PDI03;User ID=iotadmin;Password=ciql#wOd9ufls;",
                // Add more connection strings as needed
            };

            foreach (string connStr in connectionStrings)
            {
                try
                {
                    using (SqlConnection conn = new SqlConnection(connStr))
                    {
                        conn.Open();

                        using (SqlCommand cmd = new SqlCommand("SP_toollife_live", conn))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandTimeout = 0;

                            // Add parameters if required
                            cmd.Parameters.Add("@CompanyCode", SqlDbType.VarChar).Value = "TVS";
                            cmd.Parameters.Add("@PlantCode", SqlDbType.VarChar).Value = "TVS_Plant03";

                            using (SqlDataReader reader = cmd.ExecuteReader())
                            {
                                // Check if the reader has rows
                                if (reader.HasRows)
                                {
                                    // Iterate through the rows
                                    while (reader.Read())
                                    {
                                        string lineCode = reader["Linecode"].ToString();
                                        string connection = reader["connection"].ToString();
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
            }
        }
    }
}
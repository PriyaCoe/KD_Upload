﻿

using System;
using System.Configuration;
using System.Data.SqlClient;

namespace webjobDTU
{
    class Program
    {
        static void Main(string[] args)
        {

            string connectionstring = ConfigurationManager.ConnectionStrings["con"].ToString();
            string CompanyCode = "TVS";
            string PlantCode = "TVS_Plant03";
            string LineCode = "MA_UNIT01";



            Console.WriteLine("DatabaseDiagnostic web job started");

            SqlConnection conn = new SqlConnection(connectionstring);
            SqlCommand com;
            try
            {
                conn.Open();
                Console.WriteLine("Connection established with DB");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to establish connection with DB");
                ExceptionSetting.SendErrorTomail(ex, connectionstring, CompanyCode, PlantCode, LineCode);
            }
            try
            {
                Console.WriteLine("SP_DatabaseDiagnostics started");
                com = new SqlCommand("SP_DatabaseDiagnostics", conn);
                com.CommandType = System.Data.CommandType.StoredProcedure;
                com.CommandTimeout = 0;
                com.ExecuteNonQuery();
                Console.WriteLine("SP_DatabaseDiagnostics ended");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                conn.Close();
                ExceptionSetting.SendErrorTomail(ex, connectionstring, CompanyCode, PlantCode, LineCode);
            }

        }
    }
}

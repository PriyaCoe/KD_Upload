﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RejectionReason
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionstring = ConfigurationManager.ConnectionStrings["con"].ToString();
            string CompanyCode = "TVS";
            string PlantCode = "TVS_Plant03";
            string LineCode = "SA_UNIT02";

            

            Console.WriteLine("Reject Reason web job started");
                
            SqlConnection conn = new SqlConnection(connectionstring);
            SqlCommand com;
            try { 
                conn.Open();
                Console.WriteLine("Connection established with DB");
            }
            catch (Exception ex)
            {

                Console.WriteLine("Unable to establish connection with DB");
                ExceptionSetting.SendErrorTomail(ex, connectionstring, CompanyCode, PlantCode, LineCode);
            }
            try {
                Console.WriteLine("Reject Reason started");
                com = new SqlCommand("SP_Reject_Reasons", conn);
                com.CommandType = System.Data.CommandType.StoredProcedure;
                com.CommandTimeout = 0;
                com.ExecuteNonQuery();
                Console.WriteLine("Reject Reason ended");  
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                com= new SqlCommand(@"INSERT INTO tbl_webjoblogs(Time_stamp, Date, WebjobName, Status, Remarks) VALUES (@timeStamp,@date,@webjobName,@status,@remarks)", conn);
                com.Parameters.AddWithValue("@timeStamp", "");
                com.Parameters.AddWithValue("@date", "");
                com.Parameters.AddWithValue("@webjobName", "");
                com.Parameters.AddWithValue("@status", "0");
                com.Parameters.AddWithValue("@remarks", "");
                conn.Close();
                ExceptionSetting.SendErrorTomail(ex, connectionstring, CompanyCode, PlantCode, LineCode);
            }
            
            
            
        }
    }
}
